import React from 'react';
export default function GlassCard() {
  return <div style={{padding:20, background:'#eee', borderRadius:12}}>GlassCard placeholder</div>;
}

import React from 'react';
export default function Footer() {
  return <div style={{padding:20, background:'#eee', borderRadius:12}}>Footer placeholder</div>;
}

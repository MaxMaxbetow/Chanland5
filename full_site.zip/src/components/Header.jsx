import React from 'react';
export default function Header() {
  return <div style={{padding:20, background:'#eee', borderRadius:12}}>Header placeholder</div>;
}

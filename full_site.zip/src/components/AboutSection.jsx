import React from 'react';
export default function AboutSection() {
  return <div style={{padding:20, background:'#eee', borderRadius:12}}>AboutSection placeholder</div>;
}
